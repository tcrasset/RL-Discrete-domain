import math
import numpy as np
import random

# CONSTANTS
UP = (-1, 0)
DOWN = (1, 0)
LEFT = (0, -1)
RIGHT = (0, 1)
directions = [UP, DOWN, LEFT, RIGHT]


def expectedReward(current, action, reward_matrix, beta=0):
    """
    Computes the expected reward of a state.
    The beta paramter specifies the threshold for the
    stochastic dynamics, if none is given, it defaults to 0, 
    that is a purely deterministic approach.

    Arguments:
    ---------
    - current: Tuple containing the coordinates of the current state
    - action: Tuple containing the action to take in the current state 
    - reward_matrix: matrix containing the rewards of each cell
    - beta: threshold for stochastic dynamics

    Returns:
    --------
    Integer value fo the expected reward of the cell
    """
    coords = dynamics(current, 
                    action, 
                    reward_matrix.shape[0], 
                    reward_matrix.shape[1])

    deterministic = rewardAtPosition(reward_matrix, coords)
    stochastic = rewardAtPosition(reward_matrix, (0, 0))
    return (1 - beta) * deterministic + beta * stochastic

def probability(current, action, test_state, reward_matrix, beta):
    """
    Computes the probability of reaching a next state
    by taking the given action in the current state. 
    Arguments:
    ---------
    - current: Tuple containing the coordinates of the current state
    - action: Tuple containing the action to take in the current state 
    - test_state: Tuple containing the coordiantes of the next state to test
    - reward_matrix: matrix containing the rewards for each cell
    - beta: threshold for stochastic dynamics
    Returns:
    --------
    Float value between 0 and 1
    """

    dim_x = reward_matrix.shape[0]
    dim_y =reward_matrix.shape[1]
    next_state = dynamics(current, action, dim_x, dim_y)

    if beta == 0: # Deterministic
        if next_state == test_state:
            return 1 
        else:
            return 0
    else: # Stochastic
        if test_state == (0,0):
            return beta
        elif next_state == test_state:
            return (1 -beta)  
        else:
             return 0


def rewardAtPosition(reward_matrix, coords):
    """Returns the reward from a given cell whose coordinates are given
    by a Point class
    Arguments:
    ----------
    - reward_matrix: matrix containing the rewards for each cell
    - coords : Point instance describing the cell for which to extract the reward
    Returns:
    ----------
    - integer reward
    """
    return reward_matrix[coords]


def dynamics(curr, direction, dim_x, dim_y):
    """
    Returns the next state given the current state
    and the action to perform
    Arguments:
    ----------
    - curr : tuple giving current state coordinates
    - direction: tuple giving the action to take
    - dim_x: upper bound of the first dimension
    - dim_y: upper bound of the second dimension
    Returns:
    --------
    Tuple corresponding to the coordinates of the next state
    """
    maximum_x = max(curr[0] + direction[0], 0)
    maximum_y = max(curr[1] + direction[1], 0)
    return (min(maximum_x, dim_x - 1), min(maximum_y, dim_y - 1))


def cumulativeExpectedReward(action, reward_matrix, discount, N, beta=0):
    """
    Computes the cumulative expected reward for a whole grid
    Add the beta parameter to use a stochastic approach
    Without it, a deterministic approach is chosen.
    Arguments:
    ----------
    - action: tuple giving the next action to take
    - reward_matrix: matrix containing the rewards for each cell
    - discount : discount value between each iteration
    - N : number of iterations to perform
    - beta: probability threshold for stochastic dynamics
    Returns:
    ----------
    - Matrix with the same shape as reward_matrix containing
    in each cell the cumulative expected reward 
    """
    dim_x = reward_matrix.shape[0]
    dim_y = reward_matrix.shape[1]
    current_J = np.zeros_like(reward_matrix, dtype=float)
    for i in range(0, N):
        previous_J = current_J

        for x in range(dim_x):
            for y in range(dim_y):
                next_point = dynamics((x, y), action, dim_x, dim_y)
                current_J[(x, y)] = expectedReward((x,y), action, reward_matrix, beta) \
                    + discount * \
                    ((1 - beta) *
                     previous_J[next_point] + beta * previous_J[(0, 0)])
    return current_J


if __name__ == '__main__':
    discount = 0.99
    """ --------> y
        |
        |
        |
        |
        v
        x
    """
    g = np.matrix([[-3, 1, -5, 0, 19],
                   [6, 3, 8, 9, 10],
                   [5, -8, 4, 1, -8],
                   [6, -9, 4, 19, -5],
                   [-20, -17, -4, -3, 9]])

    prob = np.zeros_like(g, dtype=float)
    for x in range(g.shape[0]):
        for y in range(g.shape[1]):
            next_state = dynamics((x,y), RIGHT, g.shape[0], g.shape[1])
            prob[(x,y)] = probability((x,y), RIGHT, next_state,g,0)

    print(prob)

    print("Initial matrix\n", g)
    # Deterministic cumulativeExpectedReward
    print("Cumulative reward with deterministic dynamics, 10000 iterations :\n",
          cumulativeExpectedReward(RIGHT, g, discount, 10000))
    # Stochastic cumulativeExpectedReward
    print("Cumulative expected reward with stochastic dynamics, beta = 0.5, 10000 iterations :\n",
          cumulativeExpectedReward(RIGHT, g, discount, 10000, 0.5))
