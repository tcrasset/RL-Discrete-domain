import math
import numpy as np
import random

class Point:
    """Simple class to represent a cell in the grid"""
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __str__(self):
        return "({},{})".format(self.x,self.y)
      

#CONSTANTS
UP = Point(0,1)
DOWN  = Point(0,-1)
LEFT = Point(-1,0)
RIGHT = Point(1,0)
directions = [UP, DOWN, LEFT, RIGHT]


def dynamics(curr, direction, reward_matrix, beta = None):

    if(beta is None): #Deterministic
        maximum_x = max(addPoints(curr,direction).x, 0)
        maximum_y = max(addPoints(curr,direction).y, 0)
        return Point(min(maximum_x, reward_matrix.shape[1]-1), min(maximum_y, reward_matrix.shape[0]-1))
    else: #Stochastic
        w = random.random()
        if(w <= 1 - beta):
            maximum_x = max(addPoints(curr,direction).x, 0)
            maximum_y = max(addPoints(curr,direction).y, 0)
            return Point(min(maximum_x, reward_matrix.shape[1]-1), min(maximum_y, reward_matrix.shape[0]-1))
        else:
            return Point(0,0)

def rewardAtPosition(reward_matrix, pos):
    """Returns the reward from a given cell whose coordinates are given
    by a Point class
    Arguments:
    ----------
    - reward_matrix: matrix containing the rewards for each cell
    - pos : Point instance describing the cell for which to extract the reward
    Returns:
    ----------
    - integer reward
    """
    return reward_matrix[(pos.x,pos.y)]

def addPoints(p1, p2):
    """Add two Points together by additioning their respective coordinates
        Arguments:
        ----------
        - p1 and p2: two Point instances
        Returns:
        ----------
        - Point with the coordinates of the added points
    """
    return Point(p1.x + p2.x, p1.y + p2.y)

def expectedReward(policy, reward_matrix, discount, N, beta=None):
    """Computes the expected reward for a whole grid
       Add the beta parameter to use a stochastic approach
       Without it, a deterministic approach is chosen.
        Arguments:
        ----------
        - policy: Point that acts like direction
        - reward_matrix: matrix containing the rewards for each cell
        - discount : discount
        - N : Number of recursive iterations to perform
        - beta: Threshold for stochastic dynamics
        Returns:
        ----------
        - Point with the coordinates of the added points
    """

    J = np.zeros_like(reward_matrix)
    for col in range(reward_matrix.shape[1]):
        for row in range(reward_matrix.shape[0]): 
            total = 0
            x0 = Point(col,row)
            for it in range(0,N):
                next_point = dynamics(x0, policy, reward_matrix, beta)
                total += pow(discount,it) * rewardAtPosition(reward_matrix, next_point)
                x0 = next_point

            J[(col,row)] = total
    return J

def expectedRewardAux(state, policy, reward_matrix, discount, N, beta=None):
    """Computes the expected reward for a given state
       Add the beta parameter to use a stochastic approach
       Without it, a deterministic approach is chosen.
        Arguments:
        ----------
        - state: cell which want to compute the expected reward of
        - reward_matrix: matrix containing the rewards for each cell
        - discount : discount
        - N : Number of recursive iterations to perform
        - beta: Threshold for stochastic dynamics
        Returns:
        ----------
        - Point with the coordinates of the added points
    """
    if(N == 0):
        return 0
    else:
        next_point = dynamics(state, policy,reward_matrix, beta)
        return (rewardAtPosition(reward_matrix, next_point) +
                discount * expectedRewardAux(next_point, 
                                            policy, 
                                            reward_matrix, 
                                            discount, 
                                            N-1,
                                            beta))

if __name__ == '__main__':
    discount = 0.99

    g = np.matrix([[-20, -17, -4, -3, 9],
                    [6, -9, 4, 19, -5],
                    [5, -8, 4, 1, -8],
                    [6, 3, 8, 9, 10],
                    [-3, 1, -5, 0, 19]])

    print("Initial matrix\n", g)
    #Deterministic dynamics
    print("N_iter 1")
    print("Expected cumulative reward with determinism\n", expectedReward(UP, g, discount, 1))
    print("N_iter 2")
    print("Expected cumulative reward with determinism\n", expectedReward(UP, g, discount, 2))
    print("N_iter 3")
    print("Expected cumulative reward with determinism\n", expectedReward(UP, g, discount, 3))
    print("N_iter 10000 UP")
    print("Expected cumulative reward with determinism\n", expectedReward(UP, g, discount, 10000))

    #Stochastic dynamics
    beta = 0.7
    print("N_iter 1")
    print("Expected cumulative reward with Stochastic\n", expectedReward(UP, g, discount, 1, beta))
    print("N_iter 2")
    print("Expected cumulative reward with Stochastic\n", expectedReward(UP, g, discount, 2, beta))
    print("N_iter 3")
    print("Expected cumulative reward with Stochastic\n", expectedReward(UP, g, discount, 3, beta))
    print("N_iter 10000")
    print("Expected cumulative reward with Stochastic\n", expectedReward(UP, g, discount, 10000, beta))




